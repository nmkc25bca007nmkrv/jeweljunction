JEWELJUNCTION - JEWELLERY COLLECTION SHOWCASE

Files included:
1. index.html - Website structure and content
2. style.css - Website styling and responsive layout
3. script.js - Search, product detail alerts, and sample contact form

HOW TO RUN:
1. Extract the ZIP file.
2. Open the JewelJunction folder.
3. Double-click index.html to open it in your browser.
4. Keep all three files in the same folder.

NOTES:
- Internet access is needed for the online jewellery images.
- Prices are sample demonstration prices.
- The contact form only shows a confirmation message. It does not send emails or save data.
